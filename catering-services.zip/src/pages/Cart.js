import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import axios from 'axios';

function Cart() {
  const [cartItems, setCartItems] = useState([]);
  const [total, setTotal] = useState(0);
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [orderPlaced, setOrderPlaced] = useState(false);

  useEffect(() => {
    const userData = sessionStorage.getItem("userdata");
    if (userData) {
      try {
        const parsedUser = JSON.parse(userData);
        setUser(parsedUser);
        fetchCartItems(parsedUser.id);
      } catch (e) {
        console.error("Error parsing user data:", e);
        sessionStorage.removeItem("userdata");
        setLoading(false);
      }
    } else {
      setLoading(false);
    }
  }, []);

  const fetchCartItems = (userId) => {
    axios.get(`http://localhost/catering-api/cart/cart.php?user_id=${userId}`)
      .then(response => {
        if (response.data && response.data.items) {
          setCartItems(response.data.items);
          const calculatedTotal = response.data.items.reduce((sum, item) => sum + (item.price * item.quantity), 0);
          setTotal(calculatedTotal);
        }
        setLoading(false);
      })
      .catch(error => {
        console.error('Error fetching cart:', error);
        setLoading(false);
      });
  };

  const updateQuantity = (itemId, newQuantity) => {
    if (newQuantity < 1) {
      removeItem(itemId);
      return;
    }
    axios.post('http://localhost/catering-api/cart/update_cart.php', {
      item_id: itemId,
      quantity: newQuantity
    })
      .then(response => {
        if (response.data.success) {
          const updatedItems = cartItems.map(item =>
            item.id === itemId ? { ...item, quantity: newQuantity } : item
          );
          setCartItems(updatedItems);
          const calculatedTotal = updatedItems.reduce((sum, item) => sum + (item.price * item.quantity), 0);
          setTotal(calculatedTotal);
        }
      })
      .catch(error => {
        console.error('Error updating cart item:', error);
      });
  };

  const removeItem = (itemId) => {
    axios.post('http://localhost/catering-api/cart/remove_from_cart.php', {
      item_id: itemId
    })
      .then(response => {
        if (response.data.success) {
          const updatedItems = cartItems.filter(item => item.id !== itemId);
          setCartItems(updatedItems);
          const calculatedTotal = updatedItems.reduce((sum, item) => sum + (item.price * item.quantity), 0);
          setTotal(calculatedTotal);
        }
      })
      .catch(error => {
        console.error('Error removing cart item:', error);
      });
  };

  const placeOrder = () => {
    if (!user) {
      alert('Please login to place an order');
      return;
    }
    axios.post('http://localhost/catering-api/cart/place_order.php', {
      user_id: user.id,
      total_amount: total,
      delivery_address: user.address || '',
      special_instructions: ''
    })
      .then(response => {
        if (response.data.success) {
          setOrderPlaced(true);
          setCartItems([]);
          setTotal(0);
        } else {
          alert('Failed to place order: ' + response.data.message);
        }
      })
      .catch(error => {
        console.error('Error placing order:', error);
        alert('Failed to place order');
      });
  };

  if (loading) {
    return (
      <div className="container py-5 text-center">
        <div className="spinner-border text-primary" role="status">
          <span className="visually-hidden">Loading...</span>
        </div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="container py-5 text-center">
        <div className="alert alert-warning">
          Please <Link to="/login">login</Link> to view your cart.
        </div>
      </div>
    );
  }

  if (orderPlaced) {
    return (
      <div className="container py-5">
        <div className="row justify-content-center">
          <div className="col-md-6 text-center">
            <div className="alert alert-success">
              <h4 className="alert-heading">Order Placed Successfully!</h4>
              <p>Thank you for your order. We have received it and will process it shortly.</p>
              <hr />
              <p className="mb-0">You will receive a confirmation email shortly.</p>
            </div>
            <Link to="/menu" className="btn btn-primary mt-3">Continue Shopping</Link>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="container py-5">
      <h2 className="mb-4">Your Cart</h2>
      {cartItems.length === 0 ? (
        <div className="text-center py-5">
          <i className="fas fa-shopping-cart fa-3x text-muted mb-3"></i>
          <h4>Your cart is empty</h4>
          <p className="text-muted">Looks like you haven't added any items to your cart yet.</p>
          <Link to="/menu" className="btn btn-primary mt-3">Browse Menu</Link>
        </div>
      ) : (
        <>
          <div className="table-responsive">
            <table className="table table-hover">
              <thead>
                <tr>
                  <th>Item</th>
                  <th>Price</th>
                  <th>Quantity</th>
                  <th>Subtotal</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                {cartItems.map(item => (
                  <tr key={item.id}>
                    <td>
                      <div className="d-flex align-items-center">
                        <img src={item.image_url} alt={item.name} className="img-thumbnail me-3" style={{ width: '60px', height: '60px', objectFit: 'cover' }} />
                        <div>
                          <h6 className="mb-0">{item.name}</h6>
                          <small className="text-muted">{item.description}</small>
                        </div>
                      </div>
                    </td>
                    <td>${parseFloat(item.price).toFixed(2)}</td>
                    <td>
                      <div className="input-group input-group-sm" style={{ width: '120px' }}>
                        <button className="btn btn-outline-secondary" type="button" onClick={() => updateQuantity(item.id, item.quantity - 1)}>-</button>
                        <input type="text" className="form-control text-center" value={item.quantity} readOnly />
                        <button className="btn btn-outline-secondary" type="button" onClick={() => updateQuantity(item.id, item.quantity + 1)}>+</button>
                      </div>
                    </td>
                    <td>${(item.price * item.quantity).toFixed(2)}</td>
                    <td>
                      <button className="btn btn-sm btn-danger" onClick={() => removeItem(item.id)} title="Remove item">
                        <i className="fas fa-trash"></i>
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div className="row mt-4">
            <div className="col-md-6">
              <Link to="/menu" className="btn btn-outline-primary">
                <i className="fas fa-arrow-left me-2"></i> Continue Shopping
              </Link>
            </div>
            <div className="col-md-6 text-md-end">
              <div className="d-flex flex-column align-items-md-end">
                <h4>Total: ${total.toFixed(2)}</h4>
                <p className="text-muted mb-3">Shipping and taxes calculated at checkout</p>
                <button className="btn btn-primary btn-lg" onClick={placeOrder}>
                  <i className="fas fa-shopping-cart me-2"></i> Place Order
                </button>
              </div>
            </div>
          </div>
        </>
      )}
    </div>
  );
}

export default Cart;
