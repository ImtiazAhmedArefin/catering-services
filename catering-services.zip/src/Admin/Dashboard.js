import * as React from 'react';
import { useState } from 'react';
import { Container, Row, Col, Card, Nav, Button } from 'react-bootstrap';
import { 
  FaChartLine, 
  FaUtensils, 
  FaClipboardList, 
  FaUsers, 
  FaCog,
  FaHamburger,
  FaCalendarAlt,
  FaMoneyBillWave,
  FaShoppingCart,
  FaBars,
  FaTimes
} from 'react-icons/fa';

const Adminlayout = ({ children }) => {
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);

  const toggleSidebar = () => {
    setSidebarCollapsed(!sidebarCollapsed);
  };

  return (
    <div className="d-flex min-vh-100">
      {/* Sidebar */}
      <div 
        className={`bg-dark text-white d-flex flex-column ${sidebarCollapsed ? 'collapsed' : ''}`} 
        style={{ 
          width: sidebarCollapsed ? '70px' : '250px',
          transition: 'width 0.3s ease'
        }}
      >
        <div className="p-3 d-flex justify-content-between align-items-center">
          {!sidebarCollapsed ? (
            <h1 className="text-primary fw-bold mb-0">Cater<span className="text-dark">Serv</span></h1>
          ) : (
            <h1 className="text-primary fw-bold mb-0">C</h1>
          )}
          <Button 
            variant="dark" 
            onClick={toggleSidebar}
            className="p-1"
            style={{ marginLeft: sidebarCollapsed ? 'auto' : '0' }}
          >
            {sidebarCollapsed ? <FaBars /> : <FaTimes />}
          </Button>
        </div>
        
        <Nav className="flex-column">
          <Nav.Link href="#" className="text-white active">
            <FaChartLine className="me-2" /> 
            {!sidebarCollapsed && <span>Dashboard</span>}
          </Nav.Link>
          <Nav.Link href="#" className="text-white">
            <FaShoppingCart className="me-2" /> 
            {!sidebarCollapsed && <span>Orders</span>}
          </Nav.Link>
          <Nav.Link href="#" className="text-white">
            <FaHamburger className="me-2" /> 
            {!sidebarCollapsed && <span>Menu Items</span>}
          </Nav.Link>
          <Nav.Link href="#" className="text-white">
            <FaCalendarAlt className="me-2" /> 
            {!sidebarCollapsed && <span>Events</span>}
          </Nav.Link>
          <Nav.Link href="#" className="text-white">
            <FaUsers className="me-2" /> 
            {!sidebarCollapsed && <span>Customers</span>}
          </Nav.Link>
          <Nav.Link href="#" className="text-white">
            <FaMoneyBillWave className="me-2" /> 
            {!sidebarCollapsed && <span>Billing</span>}
          </Nav.Link>
          <Nav.Link href="#" className="text-white">
            <FaClipboardList className="me-2" /> 
            {!sidebarCollapsed && <span>Reports</span>}
          </Nav.Link>
          <Nav.Link href="#" className="text-white mt-auto">
            <FaCog className="me-2" /> 
            {!sidebarCollapsed && <span>Settings</span>}
          </Nav.Link>
        </Nav>
      </div>

      {/* Main Content */}
      <div className="flex-grow-1 bg-light" style={{ transition: 'margin-left 0.3s ease' }}>
        <Container fluid className="p-4">
          {children}
        </Container>
      </div>
    </div>
  );
};

function Dashboard() {
  // Sample data for demonstration
  const stats = [
    { title: 'Total Orders', value: '142', icon: <FaShoppingCart />, color: 'primary' },
    { title: 'Pending Orders', value: '23', icon: <FaClipboardList />, color: 'warning' },
    { title: 'Revenue', value: '$12,450', icon: <FaMoneyBillWave />, color: 'success' },
    { title: 'Active Events', value: '8', icon: <FaCalendarAlt />, color: 'info' }
  ];

  const recentOrders = [
    { id: '#ORD-001', customer: 'John Smith', items: 3, amount: '$245', status: 'Delivered' },
    { id: '#ORD-002', customer: 'Sarah Johnson', items: 5, amount: '$420', status: 'Preparing' },
    { id: '#ORD-003', customer: 'Mike Williams', items: 2, amount: '$180', status: 'Pending' },
    { id: '#ORD-004', customer: 'Emily Davis', items: 7, amount: '$680', status: 'Delivered' }
  ];

  return (
    <Adminlayout>
      <h1 className="mb-4">Dashboard</h1>
      
      {/* Stats Cards */}
      <Row className="mb-4">
        {stats.map((stat, index) => (
          <Col md={3} key={index}>
            <Card className={`border-left-${stat.color} border-left-3 shadow-sm`}>
              <Card.Body className="d-flex align-items-center">
                <div className={`me-3 text-${stat.color}`} style={{ fontSize: '2rem' }}>
                  {stat.icon}
                </div>
                <div>
                  <h6 className="text-muted">{stat.title}</h6>
                  <h3>{stat.value}</h3>
                </div>
              </Card.Body>
            </Card>
          </Col>
        ))}
      </Row>

      <Row>
        {/* Recent Orders */}
        <Col md={8}>
          <Card className="shadow-sm mb-4">
            <Card.Header className="bg-white">
              <h5 className="mb-0">Recent Orders</h5>
            </Card.Header>
            <Card.Body>
              <div className="table-responsive">
                <table className="table table-hover">
                  <thead>
                    <tr>
                      <th>Order ID</th>
                      <th>Customer</th>
                      <th>Items</th>
                      <th>Amount</th>
                      <th>Status</th>
                      <th>Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    {recentOrders.map((order, index) => (
                      <tr key={index}>
                        <td>{order.id}</td>
                        <td>{order.customer}</td>
                        <td>{order.items}</td>
                        <td>{order.amount}</td>
                        <td>
                          <span className={`badge bg-${order.status === 'Delivered' ? 'success' : order.status === 'Preparing' ? 'warning' : 'secondary'}`}>
                            {order.status}
                          </span>
                        </td>
                        <td>
                          <Button variant="outline-primary" size="sm">View</Button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </Card.Body>
          </Card>
        </Col>

        {/* Quick Actions */}
        <Col md={4}>
          <Card className="shadow-sm mb-4">
            <Card.Header className="bg-white">
              <h5 className="mb-0">Quick Actions</h5>
            </Card.Header>
            <Card.Body>
              <div className="d-grid gap-2">
                <Button variant="primary">
                  <FaShoppingCart className="me-2" /> New Order
                </Button>
                <Button variant="outline-primary">
                  <FaUtensils className="me-2" /> Add Menu Item
                </Button>
                <Button variant="outline-primary">
                  <FaCalendarAlt className="me-2" /> Schedule Event
                </Button>
                <Button variant="outline-primary">
                  <FaUsers className="me-2" /> Add Customer
                </Button>
              </div>
            </Card.Body>
          </Card>

          {/* Upcoming Events */}
          <Card className="shadow-sm">
            <Card.Header className="bg-white">
              <h5 className="mb-0">Upcoming Events</h5>
            </Card.Header>
            <Card.Body>
              <div className="d-flex align-items-center mb-3">
                <div className="me-3">
                  <div className="bg-light rounded-circle p-2 d-flex align-items-center justify-content-center" style={{ width: '50px', height: '50px' }}>
                    <FaCalendarAlt className="text-primary" />
                  </div>
                </div>
                <div>
                  <h6 className="mb-0">Corporate Lunch</h6>
                  <small className="text-muted">Tomorrow, 12:00 PM</small>
                </div>
              </div>
              <div className="d-flex align-items-center mb-3">
                <div className="me-3">
                  <div className="bg-light rounded-circle p-2 d-flex align-items-center justify-content-center" style={{ width: '50px', height: '50px' }}>
                    <FaCalendarAlt className="text-primary" />
                  </div>
                </div>
                <div>
                  <h6 className="mb-0">Wedding Reception</h6>
                  <small className="text-muted">Jun 15, 6:00 PM</small>
                </div>
              </div>
              <div className="d-flex align-items-center">
                <div className="me-3">
                  <div className="bg-light rounded-circle p-2 d-flex align-items-center justify-content-center" style={{ width: '50px', height: '50px' }}>
                    <FaCalendarAlt className="text-primary" />
                  </div>
                </div>
                <div>
                  <h6 className="mb-0">Birthday Party</h6>
                  <small className="text-muted">Jun 20, 4:00 PM</small>
                </div>
              </div>
            </Card.Body>
          </Card>
        </Col>
      </Row>
    </Adminlayout>
  );
}

export default Dashboard;